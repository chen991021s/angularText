import alldata from './data.json'
export default class LoginPage{
    //封装页面对象
    get email(){
        return cy.get(alldata.login.email)
    }
    get password(){
        return cy.get(alldata.login.password)
    }
    get loginbut(){
        return cy.get(alldata.login.loginbut)
    }
    get tips(){
        return cy.get(alldata.login.tips)
    }

    //封装常见业务流
    EncapsulationLogin(email , password){
        if(email !=""){
            this.email.clear().type(email)
        }
        if(password !=""){
            this.password.clear().type(password)
        }
        this.loginbut.click()
    }
}