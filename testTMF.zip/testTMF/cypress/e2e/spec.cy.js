import logindata from './login.json'
import Login_Page from './loginpage'
import studydata from './study/study.json'
import study_Page from '../e2e/study/studypage'
import file_Page from '../e2e/filePoj/filepage'
describe('empty spec', () => {

  // before(() =>{
  //   cy.visit('/')
  //   cy.viewport(1280, 720)
  //   let login = new Login_Page() // 定义一个对象
  //   logindata.fail.forEach(item => {
  //     login.EncapsulationLogin(item.email,item.password)
  //     cy.wait(1000)
  //     login.tips.should('contain',item.errortips)
  //   })
  // })

  //每一个it都会重新清空浏览器，使用session进行存储
  //  beforeEach每个it都会调用只有第一次是真正的登录，其余的都是调用获取缓存数据
  beforeEach(() => {  
   logindata .success.forEach( item =>{
      cy.logins(item.email,item.password)
    })
    cy.visit('/')
    cy.viewport(1280, 720)
  })

  it('登录', () => {
    cy.get('.m-topbar__userpic > .m--img-rounded').click()
    //获取本地缓存的数据
    var name = window.localStorage.getItem('fullname')
    var userinfo = window.localStorage.getItem('userinfo')
    var data = JSON.parse(userinfo) //转为json对象
    cy.get('.m-card-user__name').should('contain',name)//登录用户名正确
    cy.get('.m-nav__link-wrap > .m-nav__link-text').click()
    cy.location('pathname', {timeout: 60000}).should('include', '/setting') //等待页面加载完成
    cy.get(':nth-child(3) > .right').should('contain',data.email)
    cy.get(':nth-child(4) > .right').should('contain',data.mobile)
    cy.wait(1000)
    cy.get('.back').click()
    cy.wait(2000)
  })

  it('导航信息正确',()=>{
    var data = window.localStorage.getItem('usermenu')
    var usermenu = JSON.parse(data) //转为json对象
    //判断接口返回的数据和显示是数据长度是否一致
    cy.get('.m-menu__nav > li').its('length').should('be.eq',usermenu.length)
    //第一层导航
    for (let index = 1; index <= usermenu.length; index++) {
      const element = usermenu[index-1];
      if(element.title=='SOP文件'){
        cy.get('.m-menu__nav > :nth-child('+index+') > .m-menu__link > .m-menu__link-text').should('contain',element.title)
      }else{
        cy.get(':nth-child('+index+') > [href="javascript:;"] > .m-menu__link-text').should('contain',element.title)
        cy.get(':nth-child('+index+') > [href="javascript:;"] > .m-menu__link-text').click()
        cy.wait(1000)
        //第二层导航
        for (let j = 1; j <= element.submenu.length; j++) {
          const element2 = element.submenu[j-1];
          cy.get('.m-menu__item--open > .m-menu__submenu > .m-menu__subnav > :nth-child('+j+') > .m-menu__link > .m-menu__link-text').should('contain',element2.title)
        }
      }  
    }
  })

  it('创建试验项目',()=>{
    let studypage = new study_Page() // 定义一个对象
    studypage.menu1btn.click() //项目管理
    cy.wait(1000)
    studypage.testbtn.click() //试验项目
    cy.wait(1000)
    studypage.establishbtn.click()//创建项目
    studypage.unMargin.click() //创建项目下拉
    //输入项目名称 编号 批件号 断言按钮是否禁用 申办方 申办方下拉 科室 科室下拉 模版 保存 保存后列表断言
    studypage.establishMethod("add") 
  })

  it('编辑试验项目',()=>{
    let studypage = new study_Page() // 定义一个对象
    studypage.menu1btn.click() //项目管理
    cy.wait(1000)
    studypage.testbtn.click() //试验项目
    cy.wait(1000)
    cy.get('tbody > :nth-child(1) > .cdk-column-check').click()
    cy.get('[style="background: rgb(235, 244, 253);"] > .cdk-column-number > .brws-view-type-column-header-menu > .operationBtn > #dropdownBasic1').click()
    //输入项目名称 编号 批件号 断言按钮是否禁用 申办方 申办方下拉 科室 科室下拉 模版
    studypage.establishMethod("edit") 
  })

  it('项目启动' ,() =>{
    let studypage = new study_Page() // 定义一个对象
    studypage.ProjectOperation() //操作方法
    studypage.state.should('contain','立项')//断言项目状态
  })

  it('添加项目公告',() =>{
    let studypage = new study_Page() // 定义一个对象
    studypage.ProjectOperation()//操作方法
    studypage.NoticeOperation("add")
  })

  it('编辑公告',()=>{
    let studypage = new study_Page() // 定义一个对象
    studypage.ProjectOperation()//操作方法
    studypage.operation.click() //选中
    //编辑按钮
    cy.get('[style="background: rgb(235, 244, 253);"] > .cdk-column-remind > .brws-view-type-column-header-menu > .operationBtn > #dropdownBasic1').click()
    studypage.NoticeOperation('edit')
  })

  it('删除公告',()=>{
    var value1 = ""
    var value2 = ""
    let studypage = new study_Page() // 定义一个对象
    studypage.ProjectOperation()//操作方法
    cy.get('.mat-paginator-range-label').then(($title)=> {	
      if($title.text() !='0 条，共 0'){
          // 第1页，第1 - 5 条，共7条
          value1 = parseInt($title.text().split('，')[2].split('共')[1].split('条')[0]) //共有多少条数据
      }else{
        value1 = parseInt("0")
      } 
    })
    studypage.operation.click() //选中
    cy.get('.option').click()//删除
    cy.get('.mat-raised-button-change > .mat-button-wrapper').click()  
    cy.wait(1000)
    cy.get('.mat-paginator-range-label').then(($title)=> {	
      // 第1页，第1 - 5 条，共7条
      value2 = parseInt($title.text().split('，')[2].split('共')[1].split('条')[0]) //共有多少条数据
      expect(value2).to.equal(value1-1) //断言前后条数是否满足-1 代表删除成功
    })
  })

  it('搜索项目文件',()=>{
    var name = ""
    var number  = ""
    let filePage = new file_Page()
    filePage.Navigationbtn.click()
    filePage.Navigationbtn2.click()
    cy.wait(5000)
    cy.get('.ant-select-search__field').click()//点击输入框
    cy.get('.ant-select-dropdown-menu').find('li').its("length").then((islength)=>{
      var num =Math.ceil(Math.random()*islength);
      cy.get('.ant-select-dropdown-menu > :nth-child('+num+')').click()//随机点击列表
      cy.get('.ant-select-dropdown-menu > :nth-child('+num+')').then(($title)=> {
        name = $title.text().split(' ')[1]
        number = $title.text().split(' ')[2]
        //断言查询出来的名称和编号是否一致
        cy.get('.cdk-column-officialtitle > :nth-child(2)').should('contain',name)
        cy.get('.example-element-row > .cdk-column-studyno').should('contain',number)
        console.log(name)
        console.log(number)
      })
    })
  })

  it.only('创建工作区 新建文件夹 上传',()=>{
    var value1 = ""
    var value2 = ""
    var pjname = "test文件夹"
    let studypage = new study_Page()
    let filePage = new file_Page()
    filePage.Navigationbtn.click() //项目文件
    filePage.Navigationbtn2.click() //项目文件下一级导航
    cy.get(':nth-child(2) > .cdk-column-check').click()
    // studypage.operation.click() //选中列表第一个
    filePage.newbtn.click()//点击工作区
    //断言暂无数据图片是否存在 不存在代表有数据 进行分页数据查找
    cy.get('.table_left > #default').should('not.exist').then( ()=>{
      cy.get('.mat-paginator-range-label').then(($title)=> {	
        if($title.text() !='0 条，共 0'){
            // 第1页，第1 - 5 条，共7条
            value1 = parseInt($title.text().split('，')[2].split('共')[1].split('条')[0]) //共有多少条数据
        }else{
          value1 = parseInt("0")
        } 
      })
    })
    filePage.newbtn.click()//点击新建
    studypage.preservationbtn.should('be.disabled') //按钮是否禁用
    cy.wait(1000)
    cy.get('.form-control').type(pjname)
    cy.wait(1000)
    studypage.preservationbtn.should('not.be.disabled') //按钮是否禁用
    cy.wait(1000)
    studypage.preservationbtnclick.click()
    cy.wait(1000)
    cy.get('.mat-paginator-range-label').then(($title)=> {	
      // 第1页，第1 - 5 条，共7条
      value2 = parseInt($title.text().split('，')[2].split('共')[1].split('条')[0]) //共有多少条数据
      expect(value2).to.equal(value1+1) //断言前后条数是否满足+1 添加成功
    })
    cy.wait(1000)
    //上传
    cy.get('#uploadTest input[name="file"]').attachFile('tmf功能说明.docx')
  })
})
