import alldata from '../data.json'
export default class FilePage{
    get Navigationbtn(){
        return cy.get(alldata.fileProject.Navigationbtn)
    }
    get Navigationbtn2(){
        return cy.get(alldata.fileProject.Navigationbtn2)
    }
    get newbtn(){
        return cy.get(alldata.fileProject.newbtn)
    }
}