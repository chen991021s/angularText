import alldata from '../data.json'
import studydata from './study.json'
export default class StudyPage{
    //封装页面对象 项目管理 试验项目 创建项目 创建项目下拉
    get menu1btn(){
        return cy.get(alldata.establish.menu1btn)
    }
    get testbtn(){
        return cy.get(alldata.establish.testbtn)
    }
    get establishbtn(){
        return cy.get(alldata.establish.establishbtn)
    }
    get unMargin(){
        return cy.get(alldata.establish.unMargin)
    }
    //申办方
    get cro(){
        return cy.get(alldata.establish.cro)
    }
    get croul(){
        return cy.get(alldata.establish.croul)
    }
    //科室
    get department(){
        return cy.get(alldata.establish.department)
    }
    get departmentul(){
        return cy.get(alldata.establish.departmentul)
    }
    //pi
    get pi(){
        return cy.get(alldata.establish.pi)
    }
    get piul(){
        return cy.get(alldata.establish.piul)
    }
    //模版
    get template(){
        return cy.get(alldata.establish.template)
    }
    get templateul(){
        return cy.get(alldata.establish.templateul)
    }
    //保存按钮
    get preservationbtn(){
        return cy.get(alldata.establish.preservationbtn)
    }
    get preservationbtnclick(){
        return cy.get(alldata.establish.preservationbtnclick)
    }
    //列表
    get prname(){
        return cy.get(alldata.projectList.name)
    }
    get state(){
        return cy.get(alldata.projectList.state)
    }
    get num(){
        return cy.get(alldata.projectList.num)
    }
    //操作
    get operation(){
        return cy.get(alldata.projectList.operation)
    }
    get operationitem(){
        return cy.get(alldata.projectList.operationitem)
    }
    //公告
    get Noticebtn(){
        return cy.get(alldata.Notice.Noticebtn)
    }
    get inputs1(){
        return cy.get(alldata.Notice.inputs1)
    }
    get inputs2(){
        return cy.get(alldata.Notice.inputs2)
    }
    get page(){
        return cy.get(alldata.Notice.page)
    }
  
    //下拉
    dropDown(cro){
        //点击下拉框
        cro.click()
    }
    dropDown2(croul,classname){ 
        // 下拉数据
        croul.find('li').its('length').then((islength) =>{
            if(islength>0){
                var num =Math.ceil(Math.random()*islength);
                cy.get(classname+'> .ant-select-dropdown-menu > :nth-child('+num+')').click()
            }
        })  
    }

    // //封装常见业务流
    //创建，编辑项目
    establishMethod(type){
        var numindex = Math.floor(Math.random()*studydata.establishstudy.length);
        var name = studydata.establishstudy[numindex].name
        var num1 = studydata.establishstudy[numindex].number
        var iideno = studydata.establishstudy[numindex].iideno
        var havedata = true
        if(type=="add"){
            this.preservationbtn.should('be.disabled') //按钮是否禁用
        }
        cy.get(':nth-child(1) > .form-control').clear().type(name)//项目名称
        cy.get('.borders > :nth-child(2) > .form-control').clear().type(num1) //项目编号
        cy.get(':nth-child(3) > .form-control').clear().type(iideno)//批件号
        if(type=="add"){
            //申办方
            this.dropDown(this.cro)
            this.dropDown2(this.croul,".ng-tns-c21-10")
            //科室
            this.dropDown(this.department)
            this.dropDown2(this.departmentul,".ng-tns-c21-11")
            //pi
            this.dropDown(this.pi)
            // this.dropDown2(this.piul,".ng-tns-c21-12")
            this.piul.find('li').then($el =>{
                if($el.find('.loading-icon').length>0){
                    console.log('没有数据')
                    havedata = false   
                }else{
                    console.log('有数据')
                    this.dropDown2(this.piul,".ng-tns-c21-12")  
                    
                }
            })
            // if(havedata == false){
            //     this.dropDown(this.department)
            //     this.dropDown2(this.departmentul,".ng-tns-c21-11")
            // }
            //模版
            this.dropDown(this.template)
            this.dropDown2(this.templateul,".ng-tns-c21-13")
        }
       
        this.preservationbtn.should('not.be.disabled') //按钮是否禁用
        this.preservationbtnclick.click()//按钮点击
        //列表第一个的名称等于我创建的就创建成功
        this.prname.should('contain',name) //项目名称
        this.state.should('contain','草稿')//项目状态
        this.num.should('contain',num1)//项目编号
    
    }

    //项目操作
    ProjectOperation(){
        this.menu1btn.click() //项目管理
        cy.wait(1000)
        this.testbtn.click() //试验项目
        cy.wait(1000)
        this.operation.click()//选中第一个
        this.operationitem.click() //点击操作权限第一个
    }

    //公告添加 编辑
    NoticeOperation(type){
        var name = "标题"
        var com = "内容"
        var value1="";
        var value2= ""
        if(type=="add"){     
            cy.get('.mat-paginator-range-label').then(($title)=> {	
                if($title.text() !='0 条，共 0'){
                    // 第1页，第1 - 5 条，共7条
                    value1 = parseInt($title.text().split('，')[2].split('共')[1].split('条')[0]) //共有多少条数据
                }else{
                    value1 = parseInt("0")
                }
            })  
            cy.get('.fastener').click()//创建公告
            this.Noticebtn.should('be.disabled') //按钮是否禁用
            this.inputs1.type(name)
            this.inputs2.type(com)
            cy.get('.m-radio-inline > :nth-child(2) > span').click()
            this.Noticebtn.should('not.be.disabled') //按钮是否不禁用
            this.Noticebtn.click()
            cy.wait(1000)
            cy.get('.mat-paginator-range-label').then(($title)=> {	
            // 第1页，第1 - 5 条，共7条
            value2 = parseInt($title.text().split('，')[2].split('共')[1].split('条')[0]) //共有多少条数据
            expect(value2).to.equal(value1+1) //断言前后条数是否满足+1
            // console.log(value2%5)
            if(value2>5){
                for (let index = 0; index <(value2%5); index++) {
                    this.page.click()
                }
            }
            })
            cy.get(':last-child > .cdk-column-title > .ng-star-inserted').should('contain',name)
            cy.get(':last-child > .cdk-column-content > .ng-star-inserted').should('contain',com)
            cy.get(':last-child > .cdk-column-remind > .brws-column-header-menu > .ng-star-inserted').should('contain','否')

        }else if(type=="edit"){
            this.inputs1.clear().type(name+'编辑')
            this.inputs2.clear().type(com+'编辑')
            cy.get('.m-radio-inline > :nth-child(1) > span').click()
            this.Noticebtn.should('not.be.disabled') //按钮是否不禁用
            this.Noticebtn.click()
            cy.get(':nth-child(1) > .cdk-column-title > .ng-star-inserted').should('contain',name+'编辑')
            cy.get(':nth-child(1) > .cdk-column-content > .ng-star-inserted').should('contain',com+'编辑')
            cy.get(':nth-child(1) > .cdk-column-remind > .brws-column-header-menu > .ng-star-inserted').should('contain','是')
        }
    }
}