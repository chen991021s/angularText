import Login_Page from '../e2e/loginpage'
import 'cypress-file-upload'
// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

//登录成功  cy.session 存储登录的本地缓存 
//每一个it都会重新清空浏览器，使用session进行存储
 Cypress.Commands.add('logins', (email, password) => { 
    cy.session([email, password], () => {
        cy.visit('/')
        cy.viewport(1280, 720)
        let login = new Login_Page() // 定义一个对象
        login.EncapsulationLogin(email,password)
        //访问接口测试
        cy.request({
        url:'http://192.168.0.191:8081/logins/users',
        method:'post',
        form:true,
        body:{'email':email,'password':password}
        }).then((response) =>{
            cy.url().should('be.eq','http://192.168.0.191/')
            expect(response.status).to.eq(200)
        })
    })
 })
