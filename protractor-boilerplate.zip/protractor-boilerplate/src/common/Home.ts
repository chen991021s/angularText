import { browser, logging, $, $$, by, element, ExpectedConditions as EC, ElementFinder } from 'protractor';

export class Baidu {
   _list:any = [];

   open() {
       browser.waitForAngularEnabled(false);
       return browser.driver.get('https://www.baidu.com');
   }

   getSeachInput() {
       return $('#kw');
   }

   getSubmitBtn() {
       return $('#su');
   }

   private waitForSearchResults() {
       return browser.wait(EC.presenceOf($('.result.c-container h3')), 5000);
   }

   async getResults(): Promise<ElementFinder[]> {
       await this.waitForSearchResults();
       return await $$('.result.c-container h3 a');
   }
   
   // 获取表格内所有文件的标题 (多列)
   async getList(classNames:string[],isOne:boolean){
    let length1 = await (await element.all(by.css(classNames[0]))).length
    // for(let i=0; i<length1; i++){
    //     if(isOne){
    //         let obj: { [k: string]: string } = {};
    //         classNames.forEach(async (item:string)=>{
    //             let text1 = await element.all(by.css(item)).get(i).getText()
    //             obj[item]=text1;
    //         })
    //         this._list.push(obj) 
    //     }else{
    //         if(i!=0){
    //             let obj: { [k: string]: string } = {};
    //             classNames.forEach(async (item:string)=>{
    //                 let text1 = await element.all(by.css(item)).get(i).getText()
    //                 obj[item]=text1;
    //             })
    //             this._list.push(obj) 
    //         }
    //     }
    // }
    let val = await element(by.css(".mat-paginator-navigation-next")).getAttribute("ng-reflect-disabled")
    // 如果为false说明可以点击下一页
    if(val =='false'){
        await element(by.css(".mat-paginator-navigation-next")).click() // 点击下一页
        await  browser.driver.sleep(1000);
        await this.getList(classNames,isOne)// 再次调用次方法
    }
    return this._list
   }

   // 单列
   async getList1(className:any,isOne:boolean){
    let length1 = await (await element.all(by.css(className))).length
    // for(let i=0; i<length1; i++){
    //     if(isOne){
    //         let text1 = await element.all(by.css(className)).get(i).getText()
    //         this._list.push(text1) 
    //     }else{
    //         if(i!=0){
    //             let text1 = await element.all(by.css(className)).get(i).getText()
    //             this._list.push(text1)
    //         }
    //     }
    // }
    let val = await element(by.css(".mat-paginator-navigation-next")).getAttribute("ng-reflect-disabled")
    // 如果为false说明可以点击下一页
    if(val =='false'){
        await  browser.driver.sleep(1000);
        await element(by.css(".mat-paginator-navigation-next")).click() // 点击下一页
        await  browser.driver.sleep(1000);
        await this.getList1(className,isOne)// 再次调用次方法
    }
    return this._list
   }
}

 