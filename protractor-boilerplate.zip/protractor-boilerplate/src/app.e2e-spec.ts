import { browser, logging, $, $$, by, element, ExpectedConditions as EC } from 'protractor';
import { Baidu } from './common/Home';


describe('App', () => {

  const url = 'http://localhost:4200/context';

  beforeEach(async () => {
    await browser.waitForAngularEnabled(true);
  });
// describe('测试百度搜索', function () {
//     it('测试protractor官网会不会出现在第一个搜索结果中', async function () {
//         let baidu = new Baidu();
//         await baidu.open();

//         await baidu.getSeachInput().sendKeys('protractor');
//         await baidu.getSubmitBtn().click();

//         let results = await baidu.getResults();
//         let firstResult = await results[0].getText();
//         expect(firstResult).toBe('Protractor - end-to-end testing for AngularJS');
//     });
// });
describe('测试开始：', function () {
    it('1、测试标题', async () => {
        let api = await browser.driver.get(url);
        const title = await browser.getTitle();
        // expect(title).toContain('AbsTMF');
    });
    it('2、测试111', async () => {
      // await browser.wait(function(){
      //   return browser.isElementPresent(by.model("selectProject"));
      //  },20000);
      await  browser.driver.sleep(2000); 
      // browser.isElementPresent(by.model("selectProject"));
      let text = await element(by.model("xxx")).getText();
    });
})
//   const sId = 'S011';
//   const num = 2000;
//   it('1、测试标题', async () => {
//     await  browser.driver.sleep(num);
//     await browser.get(url);
//     const title = await browser.getTitle();
//     expect(title).toContain('ScreenDemo');
//   });
//   it('2、测试项目名称', async () => {
//     const selectProject = await element(by.id('selectProject')).getText();
//     expect(selectProject).toContain('筛选系统');
//     await  browser.driver.sleep(num);
//   });
//   it('2.5、切换中心', async () => {
//     const ngSelect =  await element(by.id('ngSelect')).click(); 
//     await  browser.driver.sleep(num);
//     let a = await element.all(by.id('option1')).click()
//     await  browser.driver.sleep(num);
//   });
//   it('3、选中仅通过', async () => {
//     const nzRadio1 =  await element(by.id('nzRadio1')).click(); 
//     await  browser.driver.sleep(num);
//   });
//   it('4、切换为未通过', async () => {
//     await element(by.id('nzRadio2')).click(); 
//     await  browser.driver.sleep(num);
//   });
//   it('5、选中日期', async () => {
//     await element(by.id('dateModel3')).click();
//     await  browser.driver.sleep(num);
//   });
//   it('6、搜索受试者', async () => {
//     // 获取输入框输入筛选号
//     await element(by.id('searchValue')).sendKeys(sId);
//     await  browser.driver.sleep(num);
//     // 点击搜索图标
//     await element(by.id('searchImg')).click();
//     await  browser.driver.sleep(num);
//   });
//   it('7、判断受试者是否正确', async () => {
//     const items =  await element.all(by.id('TableTrItems')); 
//     const screenN = await element(by.id('screenN')).getText();
//     if(items.length==1 && screenN==sId){
//       console.log('受试者信息正确')
//     }
//   });
//   it('8、点击受试者', async () => {
//     const userList =  await element.all(by.id('defaultUser')); 
//     userList[0].click()
//     browser.driver.sleep(num);
//   });
//   it('9、关闭抽屉', async () => {
//     browser.driver.sleep(num);
//     await element(by.id('cancel')).click();
//     browser.driver.sleep(num);
//   });
 
// })


  // it('获取h1',async() => {
  //   const h1 = element(by.xpath('//app-root/h1'))
  //   expect(await h1.getText()).toContain('Test Title')
  // })
  // it('点击按钮',async()=>{
  //     element(by.cssContainingText("button","hello world")).click()
  //     // 等待结果的dom元素出现，超时时间5000毫秒，超过超时时间认为测试用例执行失败
  //     await browser.wait(EC.presenceOf($('.ng-untouched')), 5000);
  //     element(by.cssContainingText("button","222")).click()
  //     // const h1 = element(by.xpath('//app-root/h1'))
  //   // expect(await h1.getText()).toContain('xxxx')
  // })
  // it('输入内容',async()=>{
  //   element(by.model('name')).sendKeys('haha')
  // })


  afterEach(async () => {

  });
});
