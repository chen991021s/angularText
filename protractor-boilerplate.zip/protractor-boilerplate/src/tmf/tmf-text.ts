import { browser, logging, $, $$, by, element, ExpectedConditions as EC } from 'protractor';
import { protractor } from 'protractor/built/ptor';
import { Baidu } from '../common/Home';

describe('App', () => {
    const url = 'http://192.168.0.191/login';
    const username = 'wuyou@abscd.com'
    let newName='吴优'
    let searchValue = '45'
    let projectName = 'WYxxx'
    let newProjectName = 'Wy123'
    let projectTitle = '项目公告wy--'
    let newProjectTitle = '项目公告1980'


    beforeEach(async () => {
        await browser.waitForAngularEnabled(false);
    });
    describe('测试开始：', function () {
        const num = 200;
        it('1、测试开始了：', async () => {
            let api = await browser.driver.get(url);
            const title = await browser.getTitle();
            expect(title).toContain('AbsTMF');
        });
        // it('2、点击确定按钮', async () => {
        //     await element(by.cssContainingText("button","登录")).click();
        // });
        // it('3、提示文字断言', async () => { 
        //    let text = await element(by.css('.m-alert--outline-2x')).getText();
        //     expect (text).toContain('请输入用户名\n密码无效，请重新输入')
        // });
        // it('4、输入密码', async () => {
        //     await element.all(by.css('.form-control')).get(1).sendKeys('123123');
        //     //  expect (text).toContain('请输入用户名\n密码无效，请重新输入')
        // });
        // it('5、点击确定按钮', async () => {
        //     await element(by.cssContainingText("button","登录")).click();
        // });
        // it('6、提示文字断言', async () => { 
        // let text = await element(by.css('.m-alert--outline-2x')).getText();
        //     expect (text).toContain('请输入用户名')
        // });
        // it('7、输入框账号', async () => { 
        // await element.all(by.css('.form-control')).get(0).sendKeys('123123');
        // });
        // it('8、点击确定按钮', async () => {
        //     await element(by.cssContainingText("button","登录")).click();
        // });
        // it('9、提示文字断言', async () => { 
        // let text = await element(by.css('.m-alert--outline-2x')).getText();
        //     expect (text).toContain('用户名无效，请重新输入')
        // });
        // it('10、输入框正确账号', async () => { 
        //     await element.all(by.css('.form-control')).get(0).sendKeys('123123@qq.com');
        // });
        // it('11、点击确定按钮', async () => {
        //     await element(by.cssContainingText("button","登录")).click();
        // });
        // it('12、提示文字断言', async () => { 
        // let text = await element(by.css('.m-alert--outline-2x')).getText();
        //     expect (text).toContain('用户名或密码不正确，请重新登录')
        //     // 清空输入框
        // });
        // it('13、密码只输入3位', async () => {
        //     await element.all(by.css('.form-control')).get(1).clear()
        //     await element.all(by.css('.form-control')).get(1).sendKeys('123');
        //     await element(by.cssContainingText("button","登录")).click();
        //     let text = await element(by.css('.m-alert--outline-2x')).getText();
        //     expect (text).toContain('密码要求最小长度是4')
        // });
        it('14、输入正确的账号和密码', async () => { 
            await element.all(by.css('.form-control')).get(0).clear()
            await element.all(by.css('.form-control')).get(1).clear()
            await element.all(by.css('.form-control')).get(0).sendKeys(username);
            await element.all(by.css('.form-control')).get(1).sendKeys('399898');
            await element(by.cssContainingText("button","登录")).click();
            var url = await browser.getCurrentUrl();
            await expect (url).toContain('http://192.168.0.191/')
        });
        // it('15、点击头像打开设置', async () => { 
        //     await element(by.css('.m-topbar__userpic')).click();
        //     await element.all(by.css('.m-nav__link-text')).get(0).click();
        // });
        // it('16、获取邮箱与登录时的邮箱进行比较', async () => { 
        //     let account = await element.all(by.css('.right')).get(2).getText();
        //     let name = account.split(' ')[0]
        //     await expect (name).toContain(username)
        // });
        // it('17、编辑姓名', async () => { 
        //     await element.all(by.css('.edit')).get(0).click(); 
        //     await element(by.css('.form-control')).clear(); 
        //     await element(by.css('.form-control')).sendKeys(newName); 
        //     await element(by.cssContainingText("button","保存")).click();
        //     let name = await element.all(by.css('.right')).get(1).getText();
        //     let rightName = name.split(' ')[0]
        //     await  browser.driver.sleep(num*5);
        //     await expect (rightName).toContain(newName)
        // });
        // it('18、姓名是否一致', async () => { 
        //     await element(by.css('.m-topbar__userpic')).click();
        //     let oldName = await element(by.css('.m-card-user__name')).getText(); 
        //     await expect (oldName).toContain(newName)
            
        // });
        // it('20、退出登录', async () => { 
        //     await element.all(by.css('.m-nav__link-text')).get(2).click();
        //     await  browser.driver.sleep(num);
        //     // 判断路由是否是login
        //     var url = await browser.getCurrentUrl();
        //     await expect (url).toContain('http://192.168.0.191/login')
        //     await  browser.driver.sleep(num*10);
        //     // 重新登录 
        //     await element.all(by.css('.form-control')).get(0).sendKeys(username);
        //     await element.all(by.css('.form-control')).get(1).sendKeys('399898');
        //     await element(by.cssContainingText("button","登录")).click();
        //     var url = await browser.getCurrentUrl();
        //     await expect (url).toContain('http://192.168.0.191/')
        // });
        // it('19、搜索', async () => { 
        //     await element(by.css('.m-header-search__input')).sendKeys(searchValue)
        //     // 点击键盘回车
        //     browser.actions().sendKeys(protractor.Key.ENTER).perform();
        // });
        // it('20、断言搜索结果', async () => {
        //     let total=0;
        //     let _list:any = []; // 文件标题
        //     // 文件标题
        //     let length = await (await element.all(by.css('.filename'))).length;
        //     for(let i=0; i<length; i++){
        //         let text = await element.all(by.css('.filename')).get(i).getText();
        //         let text2 = await element.all(by.xpath('//div[@class="ng-star-inserted"]//div[@style="margin:0px 0 15px 42px;"]/p')).get(i).getText()
        //         _list.push(text+text2)
        //     }
        //     _list.forEach((element:any) => {
        //         if(element.indexOf(searchValue) != -1 ) total ++
        //     });
        //     // 转为字符串进行比较
        //     await expect (total+'').toContain(_list.length+'')
        //     await  browser.driver.sleep(num);
        // });
        // it('21、路由跳转', async () => { 
        //     await element.all(by.css('.m-menu__link-text')).get(0).click()
        //     await element.all(by.css('.m-menu__link-text')).get(1).click()
        //     let routerText =  await element.all(by.css('.m-menu__link-text')).get(1).getText()
        //     let title = await element(by.css('.firstTitle')).getText()
        //     // 断言标题
        //     await expect (title).toContain(routerText)
        //     //断言路由
        //     // let url = await (await browser.getCurrentUrl()).split('.191/')[1];
        //     // await expect (url).toContain('studymanagement/page')
        // });
        // it('22、创建项目', async () => { 
        //     await element(by.css('.rightBtnSty')).click()
        //     await element.all(by.css('.unMargin')).get(6).click() // 点击创建项目按钮
        //     //在弹窗中进行输入 
        //     let length = await (await element.all(by.css('.form-control'))).length
        //     for (let i =0; i<length-1; i++){
        //             await element.all(by.css('.form-control')).get(i).sendKeys(projectName)
        //     }
        // });
        // it('23、选中下拉框', async () => { 
        //     for (let i =0; i<4; i++){
        //         await element.all(by.css('.m-input')).get(i).click()
        //         await element.all(by.xpath(`//div[@id="cdk-overlay-${i+2}"]//li`)).get(i==1?6:0).click()
        //     }
        //     // 点击保存
        //     await element(by.cssContainingText("span","保存")).click();
        // })
        // it('24、验证', async () => { 
        //    await  browser.driver.sleep(num*10);
        //    let text = await element.all(by.css('.mat-column-name')).get(1).getText() 
        //    await expect (text).toContain(projectName)
        //    let text2 = await element.all(by.css('.cdk-column-state')).get(1).getText() 
        //    await expect (text2).toContain("草稿")
        // })
        // it('27、选中项目进行修改', async () => { 
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        //     // await element.all(by.css('.operationBtn1')).get(0).click()
        //     await element.all(by.css('.option')).get(2).click()
        //     //修改项目名称
        //      //在弹窗中进行输入 
        //      let length = await (await element.all(by.css('.form-control'))).length
        //      for (let i =0; i<length; i++){
        //         await element.all(by.css('.form-control')).get(i).clear()
        //         await element.all(by.css('.form-control')).get(i).sendKeys(newProjectName) 
        //      }
        //     await element(by.cssContainingText("span","保存")).click();
        //     await  browser.driver.sleep(num*5);
        // });
        // it("验证是否成功修改",async ()=> {
        //     // 验证是否成功修改
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        //     // await element.all(by.css('.operationBtn1')).get(0).click()
        //     await element.all(by.css('.option')).get(2).click()
        //     let length = await (await element.all(by.css('.form-control'))).length
        //     for (let i =0; i<length; i++){
        //         await  browser.driver.sleep(num);
        //         let text = await element.all(by.css('.form-control')).get(0).getAttribute("value")
        //         await expect (text).toContain(newProjectName)
        //     }
        //     await element(by.cssContainingText("span","保存")).click();
        //     await  browser.driver.sleep(num*5);
        // })
        // it('25、项目启动', async () => { 
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        //     let title = element.all(by.css('.option')).get(0).getText()
        //     await expect (title).toContain("项目启动")
        //     await element.all(by.css('.option')).get(0).click()
        //     await  browser.driver.sleep(num*5);
        // })
        // it('26、验证状态', async () => { 
        //     /// 验证状态是否改变为立项
        //     let text = await element.all(by.css('.mat-column-name')).get(1).getText() 
        //     await expect (text).toContain(newProjectName)
        //     let text2 = await element.all(by.css('.cdk-column-state')).get(1).getText() 
        //     await expect (text2).toContain("立项")
        // })
        // it('进入项目公告页', async () => {
        //     let texts = await element.all(by.css('.mat-column-name')).get(1).getText() 
        //     await expect (texts).toContain(newProjectName)
        //     let proName = await element.all(by.css('.cdk-column-state')).get(1).getText() 
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        //     let title = element.all(by.css('.option')).get(proName == "草稿"?1:0).getText()
        //     await expect (title).toContain("项目公告")
        //     await element.all(by.css('.option')).get(proName == "草稿"?1:0).click() 
        // })
        // it('27、添加项目公告', async () => { 
        //     // 点击添加公告按钮
        //     await element(by.css('.fastener')).click()
        //     //在弹窗中进行输入 
        //     let length = await (await element.all(by.css('.form-control'))).length
        //     for (let i =0; i<length-1; i++){
        //         await element.all(by.css('.form-control')).get(i).sendKeys(projectTitle)
        //     }
        //     // 单选
        //     await element.all(by.css('.m-radio')).get(1).click()
        //     let radioValue = await element.all(by.css('.m-radio')).get(1).getText()
        //     // 文件上传
        //     await element(by.css('.webuploader-element-invisible')).sendKeys('C:/Users/EDZ/Pictures/asstes/2.png')
        //     // 点击确定 
        //     await element.all(by.css('.mat-button-wrapper')).get(1).click()
        //     // 验证是否添加成功
        //     await  browser.driver.sleep(1000); //等待1s
        //     let text = await element.all(by.css('.mat-column-title')).get(1).getText() 
        //     expect (text).toContain(projectTitle)
        //     let text1 = await element.all(by.css('.mat-column-content')).get(1).getText() 
        //     expect (text1).toContain(projectTitle)
        //     let text2 = await element.all(by.css('.mat-column-remind')).get(1).getText() 
        //     expect (text2).toContain(radioValue)
        // })
        // it('28、编辑项目公告', async () => { 
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        //     await element.all(by.css('.operationBtn1')).get(0).click()
        //     let length = await (await element.all(by.css('.form-control'))).length
        //     for (let i =0; i<length-1; i++){
        //         await element.all(by.css('.form-control')).get(i).clear()
        //         await element.all(by.css('.form-control')).get(i).sendKeys(newProjectTitle)
        //     }
        //     await element.all(by.css('.m-radio')).get(0).click()
        //     let radioValue = await element.all(by.css('.m-radio')).get(0).getText()
        //     // 点击确定 
        //     await element.all(by.css('.mat-button-wrapper')).get(1).click()
        //     await  browser.driver.sleep(1000); //等待1s
        //     let text = await element.all(by.css('.mat-column-title')).get(1).getText() 
        //     expect (text).toContain(newProjectTitle)
        //     let text1 = await element.all(by.css('.mat-column-content')).get(1).getText() 
        //     expect (text1).toContain(newProjectTitle)
        //     let text2 = await element.all(by.css('.mat-column-remind')).get(1).getText() 
        //     expect (text2).toContain(radioValue)
        // })
        // it('28、删除项目公告', async () => { 
        //     await  browser.driver.sleep(num);
        //     let total  = await (await element.all(by.css('.mat-column-check'))).length
        //     if(total>1){
        //         await element.all(by.css('.mat-column-check')).get(1).click()
        //         let title = element(by.css('.option')).getText()
        //         await expect (title).toContain("删除")
        //         await element(by.css('.option')).click();
        //         await element(by.cssContainingText("span","确定")).click();
        //         await  browser.driver.sleep(num);
        //         // 验证
        //         let nowTotal  = await (await element.all(by.css('.mat-column-check'))).length
        //         expect (total-1+'').toContain(nowTotal+'')
        //     }else{
        //         console.log("删除项目公告异常===》：未添加项目公告")
        //     }
        // })
        // it('29、删除项目', async () => { 
        //     // 判断路由是否正确，不正确需要先跳转到试验项目
        //     let url = await (await browser.getCurrentUrl()).split('.191/')[1];
        //     await expect (url).toContain('studymanagement/page')
        //     if(url != "studymanagement/page"){
        //         await element.all(by.css('.m-menu__link-text')).get(1).click()
        //     }
        //     //删除项目
        //     await  browser.driver.sleep(num);
        //     let texts = await element.all(by.css('.mat-column-name')).get(1).getText() 
        //     await expect (texts).toContain(newProjectTitle)
        //     let proName = await element.all(by.css('.cdk-column-state')).get(1).getText() 
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        //     let title = element.all(by.css('.option')).get(proName == "草稿"?3:2).getText()
        //     await expect (title).toContain("删除")
        //     await element.all(by.css('.option')).get(proName == "草稿"?3:2).click() 
        //     // 点击弹窗的确定
        //     await element(by.cssContainingText("span","确定")).click();
        // })

        // 项目文件
        // it('1、跳转到项目文件选中一个文件', async () => { 
        //     await  browser.driver.sleep(num);
        //     await element.all(by.cssContainingText("span","项目文件")).get(0).click()
        //     await element.all(by.cssContainingText("span","项目文件")).get(1).click()
        //     // await  browser.driver.sleep(4000);
        //     // await element(by.css(".mat-paginator-navigation-next")).click()
        //     await  browser.driver.sleep(4000);
        //     await element.all(by.css('.mat-column-check')).get(1).click()
        // })
        // it('2、加星标', async () => { 
        //     let title = await element.all(by.css('.option')).get(0).getText()
        //     if(title =='加星标'){
        //         await element.all(by.css('.option')).get(0).click()
        //         // 验证是否添加成功
        //         await  browser.driver.sleep(5000);
        //         await element.all(by.css('.mat-column-check')).get(1).click()
        //         let newTitle = await element.all(by.css('.option')).get(0).getText()
        //         await expect (newTitle).toContain("取消星标")
        //     }else if(title =='取消星标'){
        //         await element.all(by.css('.option')).get(0).click()
        //         // 验证是否取消成功
        //         await  browser.driver.sleep(5000);
        //         await element.all(by.css('.mat-column-check')).get(1).click()
        //         let newTitle = await element.all(by.css('.option')).get(0).getText()
        //         await expect (newTitle).toContain("加星标")
        //     }else{
        //         console.log("加星标异常===》：",title)
        //     }
        // })
        // it('3、锁定', async () => { 
        //     let title = await element.all(by.css('.option')).get(2).getText()
        //     if(title =='锁定'){
        //         await element.all(by.css('.option')).get(2).click()
        //         // 验证是否添加成功
        //         await  browser.driver.sleep(5000);
        //         await element.all(by.css('.mat-column-check')).get(1).click()
        //         let newTitle = await element.all(by.css('.option')).get(2).getText()
        //         await expect (newTitle).toContain("取消锁定")
        //     }else if(title =='取消锁定'){
        //         await element.all(by.css('.option')).get(2).click()
        //         // 验证是否取消成功
        //         await  browser.driver.sleep(5000);
        //         await element.all(by.css('.mat-column-check')).get(1).click()
        //         let newTitle = await element.all(by.css('.option')).get(2).getText()
        //         await expect (newTitle).toContain("锁定")
        //     }else{
        //         console.log("锁定发生异常===》：",title)
        //     }
        // })
        // it('4、进入工作区', async () => {
        //     await element(by.css('.fastener')).click()
        //     await  browser.driver.sleep(num);
        // })
        // it('5、新建文件夹', async () => {
        //     await element(by.css('.fastener')).click()
        //     await  browser.driver.sleep(num);
        //     await element(by.css('.form-control')).sendKeys('pdf文件夹')
        //     await element(by.cssContainingText("span","保存")).click()
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu()
        //     let arr = await home.getList1('.cdk-column-docname',false)
        //     console.log(arr)
        //     if(arr.indexOf('pdf文件夹') != -1){
        //         console.log('上传===》： 上传成功')
        //     }else{
        //         console.log('上传===》： 未上传成功')
        //     }
        // })
        it('5、创建新文件', async () => {
            // let title = element.all(by.css('.option')).get(0).getText()
            // await expect (title).toContain("创建新文件")
            // await element.all(by.css('.option')).get(0).click()
            // await element(by.css('.form-control')).sendKeys('test')
            // await element(by.css('.ant-select-arrow')).click()
            // await  browser.driver.sleep(num);
            // await element.all(by.xpath('//div[@id="cdk-overlay-3"]//li')).get(0).click()
            // await element(by.cssContainingText("span","保存")).click()
            // let home = new Baidu()
            //     let arr = await home.getList1('.cdk-column-docname',false)
            //     if(arr.indexOf('test.pdf') != -1){
            //         console.log('上传===》： 上传成功')
            //     }else{
            //         console.log('上传===》： 未上传成功')
            //     }
            // await  browser.driver.sleep(num*20);
        })
        // it('6、上传', async () => { 
        //     await element(by.css('.webuploader-element-invisible')).sendKeys('C:/Users/EDZ/Pictures/asstes/1.docx')
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu()
        //     let arr = await home.getList1('.cdk-column-docname',false)
        //     if(arr.indexOf('1.docx') != -1){
        //         console.log('上传===》： 上传成功')
        //     }else{
        //         console.log('上传===》： 未上传成功')
        //     }
        // });
        // it('7、共享', async () => { 
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(1).click()
        //     await element(by.cssContainingText("span","创建链接")).click()
        //     await element(by.cssContainingText("span","复制链接及密码")).click()
        //     // await  browser.driver.sleep(1000); //等待1s
        //     // let val = await element.all(by.css('form-control')).get(0).getAttribute("value")
        //     await element(by.cssContainingText("span","关闭")).click() 
            
        // });
        let removeText = ""
        // it('8、删除', async () => { 
        //     await element(by.cssContainingText("span","pdf文件夹")).click()  // 进入pdf文件夹

        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     let removeText = await element.all(by.css('.cdk-column-docname')).get(1).getText()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(3).click()
        //     await element(by.cssContainingText("span","确认删除")).click() 
        //     await  browser.driver.sleep(num*10);
        //     let home = new Baidu()
        //     let arr2 = await home.getList1('.cdk-column-docname',false)
        //     if(arr2.indexOf(removeText) == -1){
        //         console.log('验证删除===》： 删除成功')
        //     }else{
        //         console.log('验证删除===》： 删除失败')
        //     }
        // });
        // /// 回收站
        // it('11、回收站', async () => { 
        //     await element.all(by.css('.secondTitle')).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     let length = await (await element.all(by.xpath('//div[contains(@class,"show")]/button'))).length
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(length-1).click()// 点击回收站
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu()
        //     let arr = await home.getList1('.cdk-column-name',false)
        //     if(arr.indexOf(removeText) != -1){
        //         console.log('回收站===》： 成功找到删除的文件')
        //     }else{
        //         console.log('回收站===》： 未找到删除的文件')
        //     }
        // });
        // it('12、还原', async () => { 
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await element.all(by.css('.back')).get(0).click() // 返回
        //     await  browser.driver.sleep(num*5);
        //     // 验证文件是否还原
        //     await element(by.cssContainingText("span","pdf文件夹")).click()  // 进入pdf文件夹
        //     let home = new Baidu()
        //     let arr = await home.getList1('.cdk-column-name',false)
        //     if(arr.indexOf(removeText) != -1){
        //         console.log('还原===》： 还原成功')
        //     }else{
        //         console.log('还原===》： 还原失败')
        //     }
            
        // });
        // it('13、清空回收站', async () => { 
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     let length = await (await element.all(by.xpath('//div[contains(@class,"show")]/button'))).length
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(length-1).click()// 点击回收站
        //     await  browser.driver.sleep(num*5);
        //     let ClassName = await element.all(by.css('.fastener')).getAttribute('class')
        //     if(ClassName == 'fastener'){
        //         // 可以点击清空按钮
        //         await element.all(by.css('.fastener')).get(0).click()
        //         await  browser.driver.sleep(num*5);
        //         await element.all(by.css(".mat-raised-button-change")).get(1).click()
        //         await  browser.driver.sleep(num*5);
        //         let nowClassName = await element.all(by.css('.fastener')).getAttribute('class')
        //         // 断言
        //         await expect (nowClassName).toContain("fastener forbidden")

        //     }else{
        //         console.log('清空回收站：===》：暂无记录')
        //     }
        // });
        let moveText = "";
        // it('9、移动', async () => { 
        //     moveText = await element.all(by.css('.cdk-column-docname')).get(2).getText()
        //     await element.all(by.css('.floatLeft')).get(1).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(5).click()
        //     await element(by.css('.ant-tree-switcher_close')).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css('.folder-name')).get(1).click()
        //     await element(by.cssContainingText("span","确定")).click() 
        //     await  browser.driver.sleep(num*10);
        //     console.log(moveText)
        // });
        // it('10、验证移动是否成功', async () => { 
        //     // 验证
        //     let home1 = new Baidu()
        //     let arr = await home1.getList1('.cdk-column-docname',false)
        //     await expect (arr.indexOf(moveText)+"").toContain("-1")
        //     await element.all(by.css('.mat-paginator-icon')).get(0).click()
        //     await  browser.driver.sleep(num)
        //     await element(by.cssContainingText("span","pdf文件夹")).click() 
        //     await  browser.driver.sleep(num*10);
        //     let home2 = new Baidu()
        //     let arr2 = await home2.getList1('.cdk-column-docname',false)
        //     if(arr2.indexOf(moveText) != -1){
        //         console.log('验证移动===》： 移动成功')
        //     }else{
        //         console.log('验证移动===》： 移动失败')
        //     }
        //     // 回到上一级
        //     await element.all(by.css('.secondTitle')).get(0).click()
        // });
        // it('11、复制', async () => { 
        //     moveText = await element.all(by.css('.cdk-column-docname')).get(2).getText()
        //     await element.all(by.css('.floatLeft')).get(1).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(6).click()
        //     await element(by.css('.ant-tree-switcher_close')).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css('.folder-name')).get(1).click()
        //     await element(by.cssContainingText("span","确定")).click() 
        //     await  browser.driver.sleep(num*10);
        //     console.log(moveText)
        // });
        // it('10、验证复制是否成功', async () => { 
        //     // 验证
        //     let home1 = new Baidu()
        //     let arr = await home1.getList1('.cdk-column-docname',false)
        //     await element.all(by.css('.mat-paginator-icon')).get(0).click()
        //     await  browser.driver.sleep(num)
        //     await element(by.cssContainingText("span","pdf文件夹")).click() 
        //     await  browser.driver.sleep(num*10);
        //     let home2 = new Baidu()

        //     let arr2 = await home2.getList1('.cdk-column-docname',false)
        //     if(arr.indexOf(moveText) != -1 && arr2.indexOf(moveText) != -1 ){
        //         console.log('验证复制===》： 复制成功')
        //     }else{
        //         console.log('验证复制===》： 复制失败')
        //     }
        //     // 回到上一级
        //     await element.all(by.css('.secondTitle')).get(0).click()
        // });
        // it('12、发起协调编辑', async () => { 
        //     moveText = await element.all(by.css('.cdk-column-docname')).get(2).getText()
        //     await element.all(by.css('.floatLeft')).get(1).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(4).click()
        //     await  browser.driver.sleep(num);
        //     await element(by.css('.ant-select-selection')).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.xpath('//div[@id="cdk-overlay-3"]//li')).get(0).click()
        //     // await element.all(by.css('.cdk-overlay-container')).get(0).click() //点击遮罩层
        //     // 选中今天日期
        //     let date = new Date()
        //     // await element(by.css('.ant-calendar-picker-input')).click()
        //     // console.log(date.getDate())

        // });

        // //共享
        // it('1、跳转到共享页面', async () => { 
        //     // await element.all(by.cssContainingText("span","项目文件")).get(0).click()
        //     await element.all(by.cssContainingText("span","共享")).get(0).click()
        //     await  browser.driver.sleep(num);
        // })
        // it('2、搜索', async () => { 
        //     let total =0
        //     await element.all(by.css('.ant-calendar-picker-input')).get(0).click()
        //     await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-07-29')
        //     // 点击键盘回车
        //     browser.actions().sendKeys(protractor.Key.ENTER).perform();
        //     await element.all(by.css('.m-header-search__input')).get(1).sendKeys('p')
        //     // 点击键盘回车
        //     browser.actions().sendKeys(protractor.Key.ENTER).perform();
        //     let home = new Baidu();
        //     let arr = await home.getList([
        //         '.cdk-column-name','.cdk-column-time',
        //     ],false)
        //     for(let i=0; i<arr.length;i++){
        //         if(arr[i]['.cdk-column-name'].indexOf('p') != -1 
        //         && arr[i]['.cdk-column-time'].indexOf('2022-07-29')!= -1 ) total ++
        //     }
        //     await expect (total+'').toContain(arr.length+'')
        // })
        // it('3、删除共享', async () => { 
        //     let Text = await element.all(by.css('.cdk-column-name')).get(0).getText()
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(1).click()
        //     await element.all(by.cssContainingText("span","确认删除")).get(0).click()
        //     await  browser.driver.sleep(num*10);
        //     // 验证
        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-name',false)
        //     await expect (arr.indexOf(Text)+"").toContain(-1+'')
        // });
        // 文件请求
        // it('1、跳转到文件请求页面', async () => { 
        //     // await element.all(by.cssContainingText("span","项目文件")).get(0).click()
        //     await element.all(by.cssContainingText("span","文件请求")).get(0).click()
        //     await  browser.driver.sleep(num);
        // })
        // it('2、请求文件', async () => { 
        //     await element.all(by.css(".fastener")).get(0).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css(".form-control")).get(0).sendKeys('上传PDF')
        //     await element.all(by.cssContainingText("button","更改文件夹")).get(0).click()
        //     await element.all(by.css('.ant-tree-switcher_close')).get(3).click()
        //     await  browser.driver.sleep(num);
        //     let length = (await element.all(by.css('.folder-name'))).length
        //     await element.all(by.css('.folder-name')).get(length-1).click()
        //     await element.all(by.cssContainingText("span","选择文件夹")).get(0).click()
        //     // await element.all(by.css(".m-checkbox")).get(0).click() 暂不选择截止时间
        //     await element.all(by.cssContainingText("span","下一步")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.cssContainingText("span","关闭")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.requireSpanOne',true)
        //     if(arr.indexOf('上传PDF') != -1 ){
        //         console.log('验证请求文件===》： 请求文件成功')
        //     }else{
        //         console.log('验证请求文件===》： 请求文件失败')
        //     }
        // })
        // it('3、编辑', async () => { 
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
        //     await element.all(by.css(".form-control")).get(0).clear()
        //     await element.all(by.css(".form-control")).get(0).sendKeys('新名称')
        //     await element.all(by.cssContainingText("button","更改文件夹")).get(0).click()
        //     await element.all(by.css('.ant-tree-switcher_close')).get(3).click()
        //     await  browser.driver.sleep(num);
        //     let length = (await element.all(by.css('.folder-name'))).length
        //     await element.all(by.css('.folder-name')).get(length-1).click()
        //     let oldFile = await element.all(by.css('.folder-name')).get(length-1).getText()
        //     await element.all(by.cssContainingText("span","选择文件夹")).get(0).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.cssContainingText("span","保存")).get(0).click()
        //     await  browser.driver.sleep(num*10);
        //     // 验证
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
        //     let nowName = await element.all(by.css(".form-control")).get(0).getAttribute("value")
        //     expect (nowName).toContain('新名称')
        // });
        // it('4、关闭请求', async () => { 
        //     let oldName = await element.all(by.css('.requireSpanOne')).get(0).getText()
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
        //     await element.all(by.cssContainingText("span","关闭请求")).get(0).click()
        //     await  browser.driver.sleep(num*10);
        //     // 切换到已关闭的请求列表中去查询
        //     await element.all(by.css('.mat-tab-label')).get(1).click()
        //     await  browser.driver.sleep(num*10);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.requireSpanOne',true)
        //     expect (arr.indexOf(oldName)+'').toContain(-1+"")
        // });
        // it('5、重新打开', async () => { 
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.css('.mat-tab-label')).get(1).click()
        //     let oldName = await element.all(by.css('.requireSpanOne')).get(0).getText()
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.css('.floatLeft')).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.css(".mat-raised-button-change")).get(1).click()
        //     await  browser.driver.sleep(num*10);
        //     // 切换到已关闭的请求列表中去查询
        //     await element.all(by.css('.mat-tab-label')).get(0).click()
        //     await  browser.driver.sleep(num*10);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.requireSpanOne',true)
        //     expect (arr.indexOf(oldName)+'').toContain(-1+"")
        // });
        // it('500', async () => { 
        //     await  browser.driver.sleep(1000); //等待1s
        // });
    });
});
