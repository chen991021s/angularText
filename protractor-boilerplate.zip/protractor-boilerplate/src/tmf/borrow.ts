//2 个人借阅
import { browser, logging, $, $$, by, element, ExpectedConditions as EC, protractor } from 'protractor';
import { split } from 'ts-node';
import { Baidu } from '../common/Home';


describe('App', () => {
    const url = 'http://192.168.0.191/login';
    beforeEach(async () => {
        await browser.waitForAngularEnabled(false);
    });
    describe('测试开始：', function () {
        const num = 200;
        it('1、跳转到个人借阅页面', async () => { 
            await element.all(by.cssContainingText("span","档案管理")).get(0).click()
            await  browser.driver.sleep(num);
            await element.all(by.cssContainingText("span","个人借阅")).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        it('2、重置', async () => { 
            await element.all(by.css(".m-header-search__wrapper")).get(1).click()
            await  browser.driver.sleep(num);
            let length = await (await element.all(by.css(".m-input"))).length
            for(let i=0;i<length;i++){
                await element.all(by.css(".m-input")).get(i).sendKeys('1')
            }
            await element.all(by.cssContainingText("span","重置")).get(0).click()
            // 验证输入框是否都清空
            for(let i=0;i<length;i++){
               let text = await element.all(by.css(".m-input")).get(i).getAttribute("value")
               if(text !==""){
                console.log('重置===》：清空失败')
               }
            }
        });
        it('3、搜索', async () => { 
            let total = 0;
            // await element.all(by.css(".m-header-search__wrapper")).get(1).click()
            // await  browser.driver.sleep(num);
            let length = await (await element.all(by.css(".m-input"))).length
            for(let i=0;i<length;i++){
                await element.all(by.css(".m-input")).get(i).sendKeys('1')
            }
            await element.all(by.cssContainingText("span","搜索")).get(0).click()
            await  browser.driver.sleep(num);
            // 验证搜索结果
            let home = new Baidu();
            let arr = await home.getList([
                '.cdk-column-name','.cdk-column-study','.cdk-column-studyno',
            ]
                ,false)
            for(let i=0;i<arr.length;i++){
                if(arr[i]['.cdk-column-name'].indexOf('1')!=-1 
                && arr[i]['.cdk-column-study'].indexOf('1')!=-1 
                && arr[i]['.cdk-column-studyno'].indexOf('1')!=-1){
                    total ++;
                }
            }
            await expect (total+'').toContain(arr.length+'')
        });
        let bookName = ""; // 项目名称
        it('4、整盒借阅', async () => {
            await element.all(by.css(".m-header-search__wrapper")).get(1).click()
            await  browser.driver.sleep(num);
            await element.all(by.cssContainingText("span","重置")).get(0).click()
            await  browser.driver.sleep(num);
            await element.all(by.css(".m-input")).get(1).sendKeys('t')
            await element.all(by.cssContainingText("span","搜索")).get(0).click()
            await  browser.driver.sleep(num);
            await element.all(by.css(".cdk-column-check")).get(2).click()
            bookName = await element.all(by.css(".cdk-column-study")).get(2).getText()
            await element.all(by.css(".floatLeft")).get(1).click()
            await  browser.driver.sleep(num);
            // 选中日期
            await element.all(by.css('.ant-calendar-picker-input')).get(0).click()
            await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-10-21')
            // 点击键盘回车
            browser.actions().sendKeys(protractor.Key.ENTER).perform();
            await element.all(by.cssContainingText("span","提交申请")).get(0).click()
            await  browser.driver.sleep(num*10); 

        });
        it('5、在审批进度中验证', async () => { 
            let date = new Date()
            let nowDate =   date.getFullYear()+'-'+(date.getMonth() + 1)+'-'+date.getDate()
            await element.all(by.css(".mat-tab-label")).get(1).click()
            await  browser.driver.sleep(num*10); 
            let home = new Baidu();
            let arr = await home.getList([
                '.cdk-column-name','.cdk-column-approvaltime','.cdk-column-status',
            ],false)
            for(let i=0;i<arr.length; i++){
                if(arr[i]['.cdk-column-name'].split('/')[1].indexOf(bookName)!=-1
                && arr[i]['.cdk-column-approvaltime']==nowDate
                && arr[i]['.cdk-column-status'] =='待审批'){
                    console.log('===> :申请成功')
                }else{
                    await expect ('未查找到借阅记录').toContain('')
                }
            }
        });
        it('6、取消申请', async () => { 
            await element.all(by.css(".mat-tab-label")).get(1).click()
            await  browser.driver.sleep(num*10); 
            let text = await element.all(by.css('.cdk-column-name')).get(1).getText()
            await element.all(by.css('.floatLeft')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
            await  browser.driver.sleep(num); 
            await element.all(by.cssContainingText("span","确定")).get(0).click()
            // 验证是否取消
            await element.all(by.css(".mat-tab-label")).get(0).click()
            await  browser.driver.sleep(num); 
            await element.all(by.css(".mat-tab-label")).get(1).click()
            let home1 = new Baidu();
            let arr1 = await home1.getList1('.cdk-column-approvaltime',false)
            await expect (arr1.indexOf(text)+'').toContain('-1')
        });
        it('500', async () => { 
            await  browser.driver.sleep(1000); //等待1s
        });
    });
});
