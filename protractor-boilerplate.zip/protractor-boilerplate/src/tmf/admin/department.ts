// 3.部门管理
import { browser, logging, $, $$, by, element, ExpectedConditions as EC, protractor } from 'protractor';
import { split } from 'ts-node';
import { Baidu } from '../../common/Home';


describe('App', () => {
    beforeEach(async () => {
        await browser.waitForAngularEnabled(false);
    });
    describe('测试开始：', function () {
        const num = 200;
        it('1、跳转到部门管理页面', async () => { 
            await  browser.driver.sleep(num*5);
            await element.all(by.cssContainingText("span","管理员控制台")).get(0).click()
            await  browser.driver.sleep(num);
            await element.all(by.cssContainingText("span","部门管理")).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        let phone = '13545654111';
        it('2、创建部门', async () => { 
            await element.all(by.css(".fastener")).get(0).click()
            // 选择部门
            await element.all(by.css(".ant-select-selection")).get(0).click()
            await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(0).click()
            // 填写输入框
            let length = await (await element.all(by.css(".form-control"))).length
            for(let i=0; i<length; i++){
                await element.all(by.css(".form-control")).get(i).sendKeys(i==3 ?phone+'@qq.com':phone)
            }
            await element.all(by.css(".mat-raised-button-change")).get(1).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.css(".close")).get(0).click()
            await  browser.driver.sleep(num*5);
            /// 验证是否添加成功
            let home = new Baidu();
            let arr = await home.getList1('.cdk-column-name',false)
            if(arr.indexOf(phone)!=-1){
                console.log('创建部门====》：成功')
            }else{
                console.log('创建部门====》：失败')
            }
        })
        it('3、编辑', async () => { 
            await element.all(by.css(".cdk-column-check")).get(1).click()
            await element.all(by.css(".floatLeft")).get(0).click()
            await element.all(by.css(".form-control")).get(0).clear()
            await element.all(by.css(".form-control")).get(0).sendKeys('部门1')
            await element.all(by.css(".mat-raised-button-change")).get(1).click()
            await  browser.driver.sleep(num*5);
            /// 验证是否编辑成功
            let home = new Baidu();
            let arr = await home.getList1('.cdk-column-name',false)
            if(arr.indexOf(phone)!=-1){
                console.log('编辑部门====》：成功')
            }else{
                console.log('编辑部门====》：失败')
            }
        })
        // it('4、删除', async () => { 
        //     await  browser.driver.sleep(num*5);
        //     let text = await element.all(by.css(".cdk-column-name")).get(1).getText()
        //     await element.all(by.css(".cdk-column-check")).get(1).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css('.option')).get(0).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.cssContainingText("span","确定")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-name',false)
        //     await expect (arr.indexOf(text)+'').toContain('-1')
        // })
        // 人员管理
        // it('跳转到人员管理', async () => { 
        //     await element.all(by.cssContainingText("span","人员管理")).get(0).click()
        //     await  browser.driver.sleep(num*5)
        // })
        let phone1= '13098776766';
        // it('1、创建用户', async () => { 
        //     await element.all(by.css(".fastener")).get(0).click()
        //     // 选择部门
        //     await element.all(by.css(".ant-select-selection")).get(0).click()
        //     await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(0).click()
        //     // 填写输入框
        //     let length = await (await element.all(by.css(".form-control"))).length
        //     for(let i=0; i<length; i++){
        //         await element.all(by.css(".form-control")).get(i).sendKeys(i==1 ?phone1+'@qq.com':phone1)
        //     }
        //     // 下拉框
        //     await element.all(by.css(".ant-select-selection")).get(1).click()
        //     await element.all(by.xpath(`//div[@id="cdk-overlay-2"]//li`)).get(0).click()
        //     await element.all(by.css(".ant-select-selection")).get(2).click()
        //     await element.all(by.xpath(`//div[@id="cdk-overlay-3"]//li`)).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     // await element.all(by.css(".mat-raised-button-change")).get(1).click()
        //     await element.all(by.cssContainingText("span","保存")).get(0).click()
        //     await  browser.driver.sleep(num*5);

        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-name',false)
        //     if(arr.indexOf(phone1)!=-1){
        //         console.log("===>创建用户成功",phone1)
        //     }else{
        //         console.log("===>创建用户失败",phone1)
        //     }
        // });
        // it('2、删除用户', async () => { 
        //     await  browser.driver.sleep(num*5);
        //     let text = await element.all(by.css(".cdk-column-name")).get(1).getText()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.cssContainingText("button","确定")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-name',false)
        //     await expect (arr.indexOf(text)+'').toContain('-1')
        // })
        // it('1、跳转到外部人员权限', async () => { 
        //     await  browser.driver.sleep(num*5);
        //     await element.all(by.cssContainingText("span","外部人员及权限")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        // })
        let phone2 = "13916882701"
        // it('2、创建外部人员用户', async () => { 
        //     await element.all(by.css(".mat-tab-label")).get(1).click()
        //     await element.all(by.css(".fastener")).get(0).click()
        //     let length = await (await element.all(by.css(".form-control"))).length
        //     for(let i=0; i<length; i++){
        //         if(i!=4&&i!=6)
        //         await element.all(by.css(".form-control")).get(i).sendKeys(i==1||i==3 ?phone2+'@qq.com':phone2)
        //     }
        //     // 下拉框
        //     await element.all(by.css(".form-control")).get(4).click()
        //     await element.all(by.cssContainingText("option","监管人员")).get(0).click()
        //     // await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(0).click()
        //     await element.all(by.css('.ant-calendar-picker-input')).get(0).click()
        //     await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-10-21')
        //     // 点击键盘回车
        //     browser.actions().sendKeys(protractor.Key.ENTER).perform();
        //     // 点击创建密码
        //     await element.all(by.cssContainingText("span","创建登录密码")).get(0).click()
        //     await element.all(by.css(".mat-raised-button-change")).get(1).click()
        //     await  browser.driver.sleep(num*10);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-realname',false)
        //     if(arr.indexOf(phone2)!=-1){
        //         console.log("===>创建外部用户成功",phone2)
        //     }else{
        //         console.log("===>创建外部用户失败",phone2)
        //     }
        // })
        // it('3、编辑外部人员', async () => { 
        //     await element.all(by.css(".mat-tab-label")).get(1).click()
        //     await  browser.driver.sleep(num*10);
        //     let reName = await element.all(by.css(".cdk-column-realname")).get(4).getText()
        //     await element.all(by.css('.floatLeft')).get(3).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
        //     await element.all(by.css(".form-control")).get(0).clear()
        //     await element.all(by.css(".form-control")).get(0).sendKeys('新用户1')
        //     await element.all(by.css(".mat-raised-button-change")).get(1).click()
        //     await  browser.driver.sleep(num*10);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-realname',false)
        //     if(arr.indexOf('新用户1')!=-1){
        //         console.log("===>编辑外部用户成功",reName)
        //     }else{
        //         console.log("===>编辑外部用户失败",reName)
        //     }
        // })
        // it('4、删除外部用户', async () => { 
        //     await  browser.driver.sleep(num*5);
        //     let text = await element.all(by.css(".cdk-column-realname")).get(4).getText()
        //     await  browser.driver.sleep(num*10);
        //     await element.all(by.css('.floatLeft')).get(3).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(1).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css(".mat-raised-button-change")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     let home = new Baidu();
        //     let arr = await home.getList1('.cdk-column-realname',false)
        //     await expect (arr.indexOf(text)+'').toContain('-1')
        // })
        it('500', async () => { 
            await  browser.driver.sleep(num*5);
        })
    });
});
