/// 5.目录模板管理
import { browser, logging, $, $$, by, element, ExpectedConditions as EC, protractor } from 'protractor';
import { split } from 'ts-node';
import { Baidu } from '../../common/Home';


describe('App', () => {
    beforeEach(async () => {
        await browser.waitForAngularEnabled(false);
    });
    describe('测试开始：', function () {
        const num = 200;
        // 目录模板管理
        it('1、跳转到目录模板管理', async () => { 
            await  browser.driver.sleep(num*5);
            await element.all(by.cssContainingText("span","管理员控制台")).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.cssContainingText("span","目录模板管理")).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        it('2、创建模板', async () => {
            await element.all(by.css('.fastener')).get(0).click()
            await  browser.driver.sleep(num);
            await element.all(by.css('.form-control')).get(0).sendKeys('测试模板1')
            await element.all(by.css('.ant-select-selection')).get(0).click()
            await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(1).click()
            let type = await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(1).getText()
            await element.all(by.cssContainingText("span","保存")).get(0).click()
            await  browser.driver.sleep(num*5);
            // 验证
            let home1 = new Baidu();
            let arr1 = await home1.getList(
                [
                    '.cdk-column-templatename',
                    '.cdk-column-templatetypeitem',
                ],      
                false
            )
            arr1.forEach((element:any) => {
                if(element['.cdk-column-templatename'] =='测试模板1' && element['.cdk-column-templatetypeitem'] ==type){
                    console.log('创建目录模板===>：成功')
                }
            });
            await element.all(by.css('.mat-paginator-icon')).get(0).click()
            await  browser.driver.sleep(num*5);

        })
        it('3、编辑', async () => { 
            await element.all(by.css(".cdk-column-check")).get(1).click()
            await element.all(by.xpath('//button[contains(@class,"floatLeft")]')).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.css('.form-control')).get(0).clear()
            await element.all(by.css('.form-control')).get(0).sendKeys('修改名称1')
            let text1= await element.all(by.css('.ant-select-selection-selected-value')).get(0).getText()
            let text2= await element.all(by.css('.ant-select-selection-selected-value')).get(1).getText()
            await element.all(by.cssContainingText("span","保存")).get(0).click()
            await  browser.driver.sleep(num*5);
            // 验证
            await element.all(by.css(".cdk-column-check")).get(1).click()
            await element.all(by.xpath('//button[contains(@class,"floatLeft")]')).get(0).click()
            await  browser.driver.sleep(num*5);
            let sendVal = await element.all(by.css('.form-control')).get(0).getAttribute("value")
            let nowText1= await element.all(by.css('.ant-select-selection-selected-value')).get(0).getText()
            let nowTtext2= await element.all(by.css('.ant-select-selection-selected-value')).get(1).getText()
            await expect (sendVal).toContain('修改名称1')
            await expect (text1).toContain(nowText1)
            await expect (text2).toContain(nowTtext2)  
            await element.all(by.cssContainingText("span","取消")).get(0).click()
            await element.all(by.css(".cdk-column-check")).get(1).click()
            await  browser.driver.sleep(num*5);
        })
        it('4、复制', async () => { 
            let text = await element.all(by.css(".cdk-column-templatename")).get(1).getText()
            let title = await element.all(by.css(".cdk-column-templatetypeitem")).get(1).getText()
            let total = await element.all(by.css(".cdk-column-folderNum")).get(1).getText()
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
            await element.all(by.css('.form-control')).get(0).sendKeys('复制模板1')
            await element.all(by.cssContainingText("span","保存")).get(0).click()
            await  browser.driver.sleep(num*5);
            // 验证
            let home1 = new Baidu();
            let arr1 = await home1.getList(
                ['.cdk-column-templatename','.cdk-column-templatetypeitem',".cdk-column-folderNum"],      
                false
            )
            arr1.forEach((element:any) => {
                if(element['.cdk-column-templatename'] =='复制模板1' && element['.cdk-column-templatetypeitem'] ==title
                && element['.cdk-column-folderNum'] ==total){
                    console.log('创建目录模板===>：成功复制：',text)
                }
            });
            await element.all(by.css('.mat-paginator-icon')).get(0).click()
        })
        it('5、删除', async () => { 
            let text = await element.all(by.css(".cdk-column-templatename")).get(1).getText()
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(1).click()
            await element.all(by.css(".mat-raised-button-change")).get(1).click()
            await  browser.driver.sleep(num*5);
            let home1 = new Baidu();
            let arr:string[] = [];
            let arr1 = await home1.getList(['.cdk-column-templatename'],false)
            console.log(arr1)
            arr1.forEach((element:any)=>{
                return arr.push(element['.cdk-column-templatename']);
            })
            await expect (arr.indexOf(text)+'').toContain('-1')
            await element.all(by.css('.mat-paginator-icon')).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        it('6、权限分配', async () => { 
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(2).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label')).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label')).get(1).click()
            let left = await element.all(by.xpath('//div[@class="ant-transfer-list-header"]//span[@class="ant-transfer-list-header-selected"]/span')).get(0).getText()
            let right = await element.all(by.xpath('//div[@class="ant-transfer-list-header"]//span[@class="ant-transfer-list-header-selected"]/span')).get(2).getText()
            let leftTotal = left.indexOf('/') != -1 ? Number(left.split('/')[0]): Number(left.split(' ')[0])
            let rightTotal = right.indexOf('/') != -1 ? Number(right.split('/')[0]) : Number(right.split(' ')[0])
            await  browser.driver.sleep(num);
            await element.all(by.css('.ant-btn-icon-only')).get(1).click()
            await  browser.driver.sleep(num);
            await element.all(by.css('.fastener')).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.css('.back')).get(0).click()
            await  browser.driver.sleep(num*5);
            // 验证
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(2).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label')).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label')).get(1).click()
            let newRight = await element.all(by.xpath('//div[@class="ant-transfer-list-header"]//span[@class="ant-transfer-list-header-selected"]/span')).get(2).getText()
            let newRightTotal = newRight.indexOf('/') != -1 ? newRight.split('/')[0] : newRight.split(' ')[0]
            await expect (newRightTotal).toContain((leftTotal+rightTotal)+"")
            await  browser.driver.sleep(num*5);
            await element.all(by.css('.back')).get(0).click()
        })

        ///  文档模板管理
        it('1、跳转到文档模板管理', async () => { 
            await  browser.driver.sleep(num*5);
            await element.all(by.cssContainingText("span","文档模板管理")).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        it('2、上传模板', async () => { 
            await element.all(by.css('.fastener')).get(0).click()
            await element.all(by.css('.webuploader-element-invisible')).get(0).sendKeys('C:/Users/EDZ/Pictures/asstes/1.docx')
            await element.all(by.css('.form-control')).get(1).sendKeys('docx模板1')
            await element.all(by.css(".ant-select-selection")).get(0).click()
            await element.all(by.xpath(`//div[@id="cdk-overlay-0"]//li`)).get(0).click()
            await element.all(by.cssContainingText("span","确定")).get(0).click()
            let home1 = new Baidu();
            let arr1 = await home1.getList(['.cdk-column-name','.cdk-column-author'],false)
            arr1.forEach((element:any)=>{
                if(element['.cdk-column-name'] =='docx模板1' && element['.cdk-column-author'] =='吴优'){
                    console.log('上传模板===》：成功上传：','docx模板1')
                }
            })
            await element.all(by.css('.mat-paginator-icon')).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        it('3、编辑文档模板', async () => { 
            await  browser.driver.sleep(num*5);
            // 获取到下拉框的索引
            let text  = await element.all(by.css(".mat-paginator-range-label")).get(0).getText() 
            let number1 = text.substring(text.length-2, text.length-1)
            await element.all(by.css(".cdk-column-check")).get(1).click()
            await element.all(by.xpath('//button[contains(@class,"floatLeft")]')).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.css('.form-control')).get(1).clear()
            await element.all(by.css('.form-control')).get(1).sendKeys('修改文件名称1')
            await element.all(by.css(".ant-select-selection")).get(0).click() 
            await element.all(by.xpath(`//div[@id="cdk-overlay-${number1}"]//li`)).get(0).click()
            await element.all(by.cssContainingText("span","确定")).get(0).click()
            await  browser.driver.sleep(num*5);
            // 验证 
            let home1 = new Baidu();
            let arr1 = await home1.getList(['.cdk-column-name','.cdk-column-author'],false)
            arr1.forEach((element:any)=>{
                if(element['.cdk-column-name'] =='修改文件名称1' && element['.cdk-column-author'] =='吴优'){
                    console.log('编辑模板===》：成功编辑：','修改文件名称1')
                }
            })
        })
        it('4、删除文档模板', async () => { 
            let text = await element.all(by.css(".cdk-column-name")).get(1).getText()
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
            await element.all(by.css(".mat-raised-button-change")).get(1).click()
            await  browser.driver.sleep(num*5);
                    let home1 = new Baidu();
            let arr:string[] = [];
            let arr1 = await home1.getList(['.cdk-column-name'],false)
            arr1.forEach((element:any)=>{
                return arr.push(arr1['.cdk-column-name']);
            })
            await expect (arr.indexOf(text)+'').toContain('-1')
            await element.all(by.css('.mat-paginator-icon')).get(0).click()
        })
        it('500', async () => { 
            await  browser.driver.sleep(num*5);
        })
    });
});
