// 4.项目绑定
import { spawn } from 'child_process';
import { browser, logging, $, $$, by, element, ExpectedConditions as EC, protractor } from 'protractor';
import { split } from 'ts-node';
import { Baidu } from '../../common/Home';


describe('App', () => {
    beforeEach(async () => {
        await browser.waitForAngularEnabled(false);
    });
    describe('测试开始：', function () {
        const num = 200;
        it('1、跳转到外部人员权限', async () => { 
            await element.all(by.cssContainingText("span","管理员控制台")).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.cssContainingText("span","外部人员及权限")).get(0).click()
            await  browser.driver.sleep(num*5);
        })
        let phone2 = "13916882709"
        it('2、创建外部人员用户', async () => { 
            await element.all(by.css(".mat-tab-label")).get(1).click()
            await element.all(by.css(".fastener")).get(0).click()
            let length = await (await element.all(by.css(".form-control"))).length
            for(let i=0; i<length; i++){
                if(i!=4&&i!=6)
                await element.all(by.css(".form-control")).get(i).sendKeys(i==1||i==3 ?phone2+'@qq.com':phone2)
            }
            // 下拉框
            await element.all(by.css(".form-control")).get(4).click()
            await element.all(by.cssContainingText("option","监管人员")).get(0).click()
            // await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(0).click()
            await element.all(by.css('.ant-calendar-picker-input')).get(0).click()
            await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-10-21')
            // 点击键盘回车
            browser.actions().sendKeys(protractor.Key.ENTER).perform();
            // 点击创建密码
            await element.all(by.cssContainingText("span","创建登录密码")).get(0).click()
            await element.all(by.css(".mat-raised-button-change")).get(1).click()
            await  browser.driver.sleep(num*10);
            let home = new Baidu();
            let arr = await home.getList1('.cdk-column-realname',false)
            if(arr.indexOf(phone2)!=-1){
                console.log("===>创建外部用户成功",phone2)
            }else{
                console.log("===>创建外部用户失败",phone2)
            }
        })
        it('3、编辑外部人员', async () => { 
            await element.all(by.css(".mat-tab-label")).get(1).click()
            await  browser.driver.sleep(num*10);
            let length = await (await element.all(by.css(".cdk-column-realname"))).length
            let reName = await element.all(by.css(".cdk-column-realname")).get(length-1).getText()
            await element.all(by.css('.floatLeft')).get(length-2).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
            await element.all(by.css(".form-control")).get(0).clear()
            await element.all(by.css(".form-control")).get(0).sendKeys('新用户1')
            await element.all(by.css(".mat-raised-button-change")).get(1).click()
            await  browser.driver.sleep(num*10);
            let home = new Baidu();
            let arr = await home.getList1('.cdk-column-realname',false)
            if(arr.indexOf('新用户1')!=-1){
                console.log("===>编辑外部用户成功",reName)
            }else{
                console.log("===>编辑外部用户失败",reName)
            }
        })
        it('4、删除外部用户', async () => { 
            await  browser.driver.sleep(num*5);
            let length = await (await element.all(by.css(".cdk-column-realname"))).length
            let text = await element.all(by.css(".cdk-column-realname")).get(length-1).getText()
            await  browser.driver.sleep(num*10);
            await element.all(by.css('.floatLeft')).get(length-2).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(1).click()
            await  browser.driver.sleep(num);
            await element.all(by.css(".mat-raised-button-change")).get(0).click()
            await  browser.driver.sleep(num*5);
            let home = new Baidu();
            let arr = await home.getList1('.cdk-column-realname',false)
            await expect (arr.indexOf(text)+'').toContain('-1')
        })
        it('1、项目绑定', async () => { 
            await  browser.driver.sleep(num*10);
            await element.all(by.css(".mat-tab-label")).get(0).click()
            await element.all(by.css(".fastener")).get(0).click()
            // 下拉框 手动点击关闭遮罩层
            await element.all(by.css(".ant-select-selection")).get(0).click()
            let length = await (await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`))).length
            await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(length-1).click()
            let username = await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(length-1).getText()
            await  browser.driver.sleep(num*5);
            await element.all(by.css(".ant-select-selection")).get(1).click()
            await element.all(by.xpath(`//div[@id="cdk-overlay-2"]//li`)).get(0).click()
            let projetname = await element.all(by.xpath(`//div[@id="cdk-overlay-2"]//li`)).get(0).getText()
            await  browser.driver.sleep(num*5);
            // 起止日期
            await element.all(by.css('.ant-calendar-picker-input')).get(0).click()
            await  browser.driver.sleep(num);
            await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-06-21')
            await  browser.driver.sleep(num);
            // 点击键盘回车
            browser.actions().sendKeys(protractor.Key.ENTER).perform();
            await  browser.driver.sleep(num);
            await element.all(by.css('.ant-calendar-picker-input')).get(1).click()
            await  browser.driver.sleep(num);
            await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-10-21')
            await  browser.driver.sleep(num);
            // 点击键盘回车
            browser.actions().sendKeys(protractor.Key.ENTER).perform();
            await  browser.driver.sleep(num*5);
            await element.all(by.cssContainingText("span","保存")).get(0).click()
            await  browser.driver.sleep(num*10);
            // 验证
            let home1 = new Baidu();
            let arr1 = await home1.getList([
                '.cdk-column-title','.cdk-column-person',
            ],false)
            for(let i=0; i<arr1.length; i++){
                if(arr1[i]['.cdk-column-title']==projetname && arr1[i]['.cdk-column-person']==username)
                console.log('项目绑定成功===》：绑定成功')
            }
        })
        it('2、编辑项目绑定', async () => { 
            let name = await element.all(by.css('.cdk-column-person')).get(1).getText()
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(0).click()
            await browser.driver.sleep(num);
            // 编辑人员
            // await element.all(by.css('.ant-select-selection__rendered')).get(0).getText()
            // await element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(0).click()
            // let newName = element.all(by.xpath(`//div[@id="cdk-overlay-1"]//li`)).get(0).getText()
            // // 编辑日期
            await element.all(by.css('.ant-calendar-picker-input')).get(0).click()
            await element.all(by.css('.ant-calendar-input')).get(0).clear()
            await element.all(by.css('.ant-calendar-input')).get(0).sendKeys('2022-06-01')
            await browser.driver.sleep(num);
            browser.actions().sendKeys(protractor.Key.ENTER).perform();
            await element.all(by.css('.ant-calendar-picker-input')).get(1).click()
            await element.all(by.cssContainingText("span","20")).get(0).click()
            await element.all(by.cssContainingText("span","保存")).get(0).click()
            await browser.driver.sleep(num*5);
            // 验证
            let home1 = new Baidu();
            let arr1 = await home1.getList([
                '.cdk-column-person','.cdk-column-time',
            ],false)
            for(let i=0;i<=arr1.length;i++){
                if(arr1[i]['.cdk-column-person']==name &&
                 arr1[i]['.cdk-column-time']=='2022-06-01-2022-6-02')
                console.log('编辑项目绑定===》：编辑成功')
            }
        })
        it('3、分配权限', async () => { 
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(2).click()
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label/span/input')).get(0).click()
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label/span/input')).get(1).click()
            let left = await element.all(by.xpath('//div[@class="ant-transfer-list-header"]//span[@class="ant-transfer-list-header-selected"]/span')).get(0).getText()
            let right = await element.all(by.xpath('//div[@class="ant-transfer-list-header"]//span[@class="ant-transfer-list-header-selected"]/span')).get(2).getText()
            let leftTotal = left.indexOf('/') != -1 ? Number(left.split('/')[0]): Number(left.split(' ')[0])
            let rightTotal = right.indexOf('/') != -1 ? Number(right.split('/')[0]) : Number(right.split(' ')[0])
            await  browser.driver.sleep(num);
            await element.all(by.css('.ant-btn-icon-only')).get(1).click()
            await  browser.driver.sleep(num);
            await element.all(by.css('.fastener')).get(0).click()
            await  browser.driver.sleep(num*5);
            await element.all(by.css('.back')).get(0).click()
            await  browser.driver.sleep(num*5);
            // 验证
            await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(0).click()
            await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(2).click()
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label/span/input')).get(0).click()
            await element.all(by.xpath('//div[@class="ant-transfer-list-header"]/label/span/input')).get(1).click()
            let newRight = await element.all(by.xpath('//div[@class="ant-transfer-list-header"]//span[@class="ant-transfer-list-header-selected"]/span')).get(2).getText()
            let newRightTotal = newRight.indexOf('/') != -1 ? newRight.split('/')[0] : newRight.split(' ')[0]
            await expect (newRightTotal).toContain((leftTotal+rightTotal)+"")
            await  browser.driver.sleep(num*5);
            await element.all(by.css('.back')).get(0).click()
        })
        // it('4、删除项目绑定', async () => { 
        //     let name = await element.all(by.css('.cdk-column-person')).get(4).getText()
        //     await element.all(by.xpath('//div[contains(@class,"floatLeft")]')).get(3).click()
        //     await element.all(by.xpath('//div[contains(@class,"show")]/button')).get(1).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.cssContainingText("span","确定")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     // 验证
        //     let home2 = new Baidu();
        //     let arr2 = await home2.getList1('.cdk-column-person',false)
        //     await expect (arr2.indexOf(name)+'').toContain('-1')
        // })
        // it('5、审计结果', async () => { 
        //     await element.all(by.css('.cdk-column-check')).get(1).click()
        //     await element.all(by.xpath('//button[contains(@class,"floatLeft")]')).get(0).click()
        //     await  browser.driver.sleep(num);
        //     await element.all(by.css('.form-control')).get(0).clear()
        //     await element.all(by.css('.form-control')).get(0).sendKeys("输入一条数据")
        //     await element.all(by.cssContainingText("span","保存")).get(0).click()
        //     await  browser.driver.sleep(num*5);
        //     // 验证
        //     await element.all(by.css('.cdk-column-check')).get(1).click()
        //     await element.all(by.xpath('//button[contains(@class,"floatLeft")]')).get(0).click()
        //     await  browser.driver.sleep(num);
        //     let val = await element.all(by.css('.form-control')).get(0).getAttribute("value")
        //     await expect (val).toContain("输入一条数据")
        // })

        /// 目录模板管理

        // it('500', async () => { 
        //     await  browser.driver.sleep(num*5);
        // })
    });
});
